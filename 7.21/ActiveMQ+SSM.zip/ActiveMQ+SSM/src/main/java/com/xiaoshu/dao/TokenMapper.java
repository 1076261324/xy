package com.xiaoshu.dao;

import com.xiaoshu.base.dao.BaseMapper;
import com.xiaoshu.entity.Token;

public interface TokenMapper extends BaseMapper<Token> {
}