package com.xiaoshu.controller;

import java.awt.font.TextMeasurer;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;

import com.xiaoshu.dao.SchoolMapper;
import com.xiaoshu.entity.School;

public class MyMessageListener implements MessageListener {

	
	@Autowired
	private SchoolMapper schoolMapper;
	@Override
	public void onMessage(Message message) {
		// TODO Auto-generated method stub
		TextMessage textMessage = (TextMessage) message;
		try {
			String string = textMessage.getText();
			int stuId = Integer.parseInt(string);
			School school = schoolMapper.selectByPrimaryKey(stuId);
			System.out.println("接收到的所属学校是="+school);
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		/*TextMessage textMessage = (TextMessage) message; 
		try {
			String stuName = textMessage.getText();
			System.out.println("接收到的学校姓名是="+stuName);
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}

}
